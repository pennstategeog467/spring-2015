**********************CATA BUS LIVE INFO UPDATES**********************

Catabusliveinfo.py - The scrpit that should run and will update shapefiles
shapefile.py - Libary mod that is used
updatingLiveInfo.json - Where Catabusliveinfo.py saves a temp file of the data from the cata site
Shapefile folder -> busLocations -  Where Catabusliveinfo.py saves the shapefiles to update the bus locations
Shapefile folder -> routeShapefiles - copy of route traces


double click Catabusliveinfo.py to run
	Currently does not work if the bus is not running :(